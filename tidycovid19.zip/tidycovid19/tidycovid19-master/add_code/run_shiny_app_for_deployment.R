# --- Shiny app ----------------------------------------------------------------


library(tidycovid19)
shiny_covid19_spread()

